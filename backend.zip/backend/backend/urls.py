from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('sales.urls')),
    path('api/forecasting/', include('forecasting.urls')),
]